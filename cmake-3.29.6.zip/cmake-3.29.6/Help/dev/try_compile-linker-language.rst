try_compile-linker-language
---------------------------

* The :command:`try_compile` and :command:`try_run` commands gained a
  ``LINKER_LANGUAGE`` option to specify the :prop_tgt:`LINKER_LANGUAGE`
  target property in the generated test project.
